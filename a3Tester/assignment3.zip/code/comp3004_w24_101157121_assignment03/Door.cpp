#include "Door.h"
#include "iostream"

void Door::open() {

    cout<<"Doors Open"<<endl;
    isOpen = true;
}

void Door::close() {

    cout<<"Doors Close"<<endl;
    isOpen = false;
}

bool Door::isDoorOpen() const {
    return isOpen;
}

#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDebug>
#include <QTimer>
#include <QObject>
#include <iostream>
#include <cmath>
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    connect(ui->pushButton, SIGNAL(released()), this, SLOT (floorG()));
    connect(ui->pushButton_2, SIGNAL(released()), this, SLOT (floor1()));
    connect(ui->pushButton_3, SIGNAL(released()), this, SLOT (floor2()));
    connect(ui->pushButton_4, SIGNAL(released()), this, SLOT (floor3()));
    connect(ui->pushButton_5, SIGNAL(released()), this, SLOT (floor4()));
    connect(ui->pushButton_6, SIGNAL(released()), this, SLOT (floor5()));
    connect(ui->pushButton_7, SIGNAL(released()), this, SLOT (floor6()));
    connect(ui->pushButton_8, SIGNAL(released()), this, SLOT (floor7()));
    connect(ui->pushButton_9, SIGNAL(released()), this, SLOT (fireButton()));
    connect(ui->pushButton_10, SIGNAL(released()), this, SLOT (helpButton()));

    connect(ui->pushButton_11, SIGNAL(released()), this, SLOT (upCall()));
    connect(ui->pushButton_11, SIGNAL(callSendElevator()), this, SLOT(callSendElevator()));//was trying to call the function send elevator in main.cpp so we can use the vector of elevators and timer

    connect(ui->pushButton_12, SIGNAL(released()), this, SLOT (downCall()));

    connect(ui->pushButton_13, SIGNAL(released()), this, SLOT (openDoor()));
    connect(ui->pushButton_14, SIGNAL(released()), this, SLOT (closeDoor()));
    connect(ui->pushButton_15, SIGNAL(released()), this, SLOT (floorSelector()));
    connect(ui->pushButton_16, SIGNAL(released()), this, SLOT (chooseElevator1()));
    connect(ui->pushButton_17, SIGNAL(released()), this, SLOT (chooseElevator2()));
    connect(ui->pushButton_18, SIGNAL(released()), this, SLOT (chooseElevator3()));



}

MainWindow::~MainWindow()
{
    delete ui;
}

QPushButton *currentUpCallButton = nullptr;

void MainWindow::floorG(){

    //QPushButton *upCallButton = qobject_cast<QPushButton*>(sender());
    //if (upCallButton){ upCallButton->setStyleSheet("background-color: yellow;");}

    QPushButton *upCallButton = qobject_cast<QPushButton*>(sender());
       if (upCallButton) {
           // Store the current upCallButton
           currentUpCallButton = upCallButton;
           upCallButton->setStyleSheet("background-color: yellow;");
       }

       int timeToTravel1Floor = 2;
       int currFloor = ui->spinBox->value();
       int totalTime = timeToTravel1Floor * std::abs(currFloor-0);

       QTimer *elevatorTimer = new QTimer(this);
       connect(elevatorTimer, &QTimer::timeout, this, &MainWindow::handleTimerRunOut);
       elevatorTimer->start(1000 * totalTime);

       qInfo("Up Call Button Pressed");



    qInfo("Ground Floor Button Pressed");
}

void MainWindow::floor1(){

    QPushButton *upCallButton = qobject_cast<QPushButton*>(sender());
    if (upCallButton){ upCallButton->setStyleSheet("background-color: yellow;");}

    qInfo("Floor 1 Button Pressed");
}

void MainWindow::floor2(){

    QPushButton *upCallButton = qobject_cast<QPushButton*>(sender());
    if (upCallButton){ upCallButton->setStyleSheet("background-color: yellow;");}

    qInfo("Floor 2 Button Pressed");
}

void MainWindow::floor3(){

    QPushButton *upCallButton = qobject_cast<QPushButton*>(sender());
    if (upCallButton){ upCallButton->setStyleSheet("background-color: yellow;");}

    qInfo("Floor 3 Button Pressed");
}

void MainWindow::floor4(){

    QPushButton *upCallButton = qobject_cast<QPushButton*>(sender());
    if (upCallButton){ upCallButton->setStyleSheet("background-color: yellow;");}

    qInfo("Floor 4 Button Pressed");
}

void MainWindow::floor5(){

    QPushButton *upCallButton = qobject_cast<QPushButton*>(sender());
    if (upCallButton){ upCallButton->setStyleSheet("background-color: yellow;");}

    qInfo("Floor 5 Button Pressed");
}

void MainWindow::floor6(){

    QPushButton *upCallButton = qobject_cast<QPushButton*>(sender());
    if (upCallButton){ upCallButton->setStyleSheet("background-color: yellow;");}

    qInfo("Floor 6 Button Pressed");
}

void MainWindow::floor7(){

    QPushButton *upCallButton = qobject_cast<QPushButton*>(sender());
    if (upCallButton){ upCallButton->setStyleSheet("background-color: yellow;");}

    qInfo("Floor 7 Button Pressed");
}

void MainWindow::fireButton(){

    QPushButton *upCallButton = qobject_cast<QPushButton*>(sender());
    if (upCallButton){ upCallButton->setStyleSheet("background-color: yellow;");}

    qInfo("Fire Button Pressed");
}

void MainWindow::helpButton(){

    QPushButton *upCallButton = qobject_cast<QPushButton*>(sender());
    if (upCallButton){ upCallButton->setStyleSheet("background-color: yellow;");}

    qInfo("Help Button Pressed");
}



void MainWindow::upCall() {
    QPushButton *upCallButton = qobject_cast<QPushButton*>(sender());
       if (upCallButton) {
           // Store the current upCallButton
           currentUpCallButton = upCallButton;
           upCallButton->setStyleSheet("background-color: yellow;");
       }

       int timeToTravel1Floor = 2;
       int currFloor = ui->spinBox->value();
       int totalTime = timeToTravel1Floor * currFloor;

       QTimer *elevatorTimer = new QTimer(this);
       connect(elevatorTimer, &QTimer::timeout, this, &MainWindow::handleTimerRunOut);
       elevatorTimer->start(1000 * totalTime);

       qInfo("Up Call Button Pressed");
}

void MainWindow::handleTimerRunOut(){

    if (currentUpCallButton) {
            // Reset the background color to none
            currentUpCallButton->setStyleSheet("background-color: none;");
            // Reset the stored button pointer
            currentUpCallButton = nullptr;
        }



}




void MainWindow::downCall(){

    QPushButton *downCallButton = qobject_cast<QPushButton*>(sender());
       if (downCallButton) {
           // Store the current upCallButton
           currentUpCallButton = downCallButton;
           downCallButton->setStyleSheet("background-color: yellow;");
       }

       int timeToTravel1Floor = 2;
       int currFloor = ui->spinBox->value();
       int totalTime = timeToTravel1Floor * currFloor;

       QTimer *elevatorTimer = new QTimer(this);
       connect(elevatorTimer, &QTimer::timeout, this, &MainWindow::handleTimerRunOut);
       elevatorTimer->start(1000 * totalTime);

       qInfo("Down Call Button Pressed");
}

void MainWindow::openDoor(){

//    QPushButton *upCallButton = qobject_cast<QPushButton*>(sender());
//    if (upCallButton){ upCallButton->setStyleSheet("background-color: yellow;");}

    qInfo("Open Door Button Pressed");
}

void MainWindow::closeDoor(){

//    QPushButton *upCallButton = qobject_cast<QPushButton*>(sender());
//    if (upCallButton){ upCallButton->setStyleSheet("background-color: yellow;");}

    qInfo("Close Door Button Pressed");
}

void MainWindow::floorSelector() {
    int currFloor = ui->spinBox->value();

    if(currFloor > 7) {
        qInfo("ERROR: INVALID FLOOR SELECTION!");
        QPushButton *upButton = findChild<QPushButton*>("pushButton_11");
        upButton->hide();
        QPushButton *downButton = findChild<QPushButton*>("pushButton_12");
        downButton->hide();

    } else if(currFloor == 7) {
        QPushButton *upButton = findChild<QPushButton*>("pushButton_11");
        upButton->hide();
        QPushButton *downButton = findChild<QPushButton*>("pushButton_12");
        downButton->show();

    } else {
        QPushButton *upButton = findChild<QPushButton*>("pushButton_11");
        upButton->show();
        QPushButton *downButton = findChild<QPushButton*>("pushButton_12");
        downButton->show();

        qInfo() << QString("Floor Selector Button Pressed, and floor is %1").arg(currFloor);
    }
}

void MainWindow::chooseElevator1(){


    qInfo("Elevator 1 Selected");

}

void MainWindow::chooseElevator2(){


    qInfo("Elevator 2 Selected");

}

void MainWindow::chooseElevator3(){


    qInfo("Elevator 1 Selected");

}



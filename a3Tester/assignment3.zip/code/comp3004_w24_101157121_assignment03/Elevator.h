#ifndef ELEVATOR_H
#define ELEVATOR_H

#include <vector>
#include <string> // Include the string header
#include "Passenger.h"
#include "Door.h"
#include "ElevatorButtons.h"

class Elevator {
private:
    int currentFloor=0;
    std::string direction; // Change Direction type variable to std::string
    std::vector<Passenger> passengers;
    Door doors;
    ElevatorButtons elevatorButtons;
    bool isIdle=true;
    float maxWeight=400.0;
    float currWeight=0.0;
public:
//    void moveUp();
//    void moveDown();
    void moveToFloor(int givenFloor);
    void openDoors();
    void closeDoors();
    void addPassenger(const Passenger& passenger);
    void removePassenger(const Passenger& passenger);
};

#endif

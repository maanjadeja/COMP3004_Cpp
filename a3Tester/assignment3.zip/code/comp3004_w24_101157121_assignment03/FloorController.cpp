#include "FloorController.h"

Elevator FloorController::allocateElevator(int floor) {
    // Placeholder logic for elevator allocation
    // For simplicity, let's just return the first elevator in the list
    if (!elevatorList.empty()) {
        return elevatorList[0];
    } else {
        // Handle the case when there are no elevators available
        // For now, let's just return a default-constructed elevator
        return Elevator();
    }
}

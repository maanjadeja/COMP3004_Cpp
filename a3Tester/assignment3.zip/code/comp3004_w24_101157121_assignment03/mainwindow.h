#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "Button.h"
#include "Door.h"
#include "DoorSensor.h"
#include "Elevator.h"
#include "ElevatorButtons.h"
#include "ExternalButtons.h"
#include "FloorController.h"
#include "Passenger.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private:
    Ui::MainWindow *ui;

private slots:
    void floorG();
    void floor1();
    void floor2();
    void floor3();
    void floor4();
    void floor5();
    void floor6();
    void floor7();
    void fireButton();
    void helpButton();
    void upCall();
    void downCall();
    void openDoor();
    void closeDoor();
    void floorSelector();
    void handleTimerRunOut();
    void chooseElevator1();
    void chooseElevator2();
    void chooseElevator3();

};



#endif // MAINWINDOW_H

#include "DoorSensor.h"

void DoorSensor::activate() {
    isActivated = true;
}

void DoorSensor::deactivate() {
    isActivated = false;
}

bool DoorSensor::isSensorActivated() const {
    return isActivated;
}

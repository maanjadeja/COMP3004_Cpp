#include "Passenger.h"

// Constructor implementation
//Passenger::Passenger(int destination) : destinationFloor(destination) {}

// Method implementation to get the destination floor
//int Passenger::getDestinationFloor() const {
//    return destinationFloor;
//}

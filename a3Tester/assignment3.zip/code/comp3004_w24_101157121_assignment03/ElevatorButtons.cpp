#include "ElevatorButtons.h"

void ElevatorButtons::pressButton(int floor) {
    // Assuming floors are indexed starting from 0
    if (floor >= 0 && floor < floorButtons.size()) {
        floorButtons[floor].press();
    } else {
        // Handle invalid floor number
    }
}

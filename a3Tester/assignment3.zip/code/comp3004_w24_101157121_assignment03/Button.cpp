#include "Button.h"

void Button::press() {
    isPressed = true;
}

void Button::release() {
    isPressed = false;
}

bool Button::isButtonPressed() const {
    return isPressed;
}

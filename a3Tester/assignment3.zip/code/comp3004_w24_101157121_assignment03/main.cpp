#include "mainwindow.h"
#include <vector>

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();
    return a.exec();

//    Elevator elevator1;
//    Elevator elevator2;
//    Elevator elevator3;

    std::vector<Elevator> elevatorList(3);
    std::vector<Passenger> passengerList;

    Passenger passenger1(5); //destination is floor 1
    Passenger passenger2(0); //destination if ground flood
    Passenger passenger3(7); // destination is floor 7

    passengerList.push_back(passenger1);
    passengerList.push_back(passenger2);
    passengerList.push_back(passenger3);


    //if up/down call button is pressed the first idle elevator should go to the floor it is being called from


}

void sendElevator(){

    std::vector<Elevator> elevatorList(3);


}

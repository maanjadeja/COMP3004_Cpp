#include "ExternalButtons.h"

void ExternalButtons::pressUp() {
    upButton.press();
}

void ExternalButtons::pressDown() {
    downButton.press();
}

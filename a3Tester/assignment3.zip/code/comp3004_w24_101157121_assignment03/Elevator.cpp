#include "Elevator.h"
#include "iostream"
#include <cstdlib>
#include <cmath>
#include <iomanip>
#include <stdlib.h>
#include <unistd.h>

void Elevator::moveToFloor(int givenFloor) {
    // Implement moving the elevator down
    // Example: currentFloor--;

    //here we will need to get the value in the spinbox like we did in mainwindow .cpp and set currentFloor equal to it




    int floorsToTravel = std::abs(givenFloor - this->currentFloor);
    this->isIdle = false;

    int timeToTravelSingleFloor = 4;
    int totalWaitTime = timeToTravelSingleFloor*floorsToTravel;
    while(totalWaitTime>0){
        sleep(1);
        totalWaitTime--;
    }

    this->currentFloor = givenFloor;
    cout <<"CURRENT FLOOR NOW IS: "<<this->currentFloor<<endl;



}

void Elevator::openDoors() {
    doors.open();
}

void Elevator::closeDoors() {
    doors.close();
}

void Elevator::addPassenger(const Passenger& passenger) {
    passengers.push_back(passenger);
}

void Elevator::removePassenger(const Passenger& passenger) {
    // Find and remove the passenger from the vector
    // Example: passengers.erase(std::remove(passengers.begin(), passengers.end(), passenger), passengers.end());
}

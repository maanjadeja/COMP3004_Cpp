/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../comp3004_w24_101157121_assignment03/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[21];
    char stringdata0[205];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 6), // "floorG"
QT_MOC_LITERAL(2, 18, 0), // ""
QT_MOC_LITERAL(3, 19, 6), // "floor1"
QT_MOC_LITERAL(4, 26, 6), // "floor2"
QT_MOC_LITERAL(5, 33, 6), // "floor3"
QT_MOC_LITERAL(6, 40, 6), // "floor4"
QT_MOC_LITERAL(7, 47, 6), // "floor5"
QT_MOC_LITERAL(8, 54, 6), // "floor6"
QT_MOC_LITERAL(9, 61, 6), // "floor7"
QT_MOC_LITERAL(10, 68, 10), // "fireButton"
QT_MOC_LITERAL(11, 79, 10), // "helpButton"
QT_MOC_LITERAL(12, 90, 6), // "upCall"
QT_MOC_LITERAL(13, 97, 8), // "downCall"
QT_MOC_LITERAL(14, 106, 8), // "openDoor"
QT_MOC_LITERAL(15, 115, 9), // "closeDoor"
QT_MOC_LITERAL(16, 125, 13), // "floorSelector"
QT_MOC_LITERAL(17, 139, 17), // "handleTimerRunOut"
QT_MOC_LITERAL(18, 157, 15), // "chooseElevator1"
QT_MOC_LITERAL(19, 173, 15), // "chooseElevator2"
QT_MOC_LITERAL(20, 189, 15) // "chooseElevator3"

    },
    "MainWindow\0floorG\0\0floor1\0floor2\0"
    "floor3\0floor4\0floor5\0floor6\0floor7\0"
    "fireButton\0helpButton\0upCall\0downCall\0"
    "openDoor\0closeDoor\0floorSelector\0"
    "handleTimerRunOut\0chooseElevator1\0"
    "chooseElevator2\0chooseElevator3"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      19,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  109,    2, 0x08 /* Private */,
       3,    0,  110,    2, 0x08 /* Private */,
       4,    0,  111,    2, 0x08 /* Private */,
       5,    0,  112,    2, 0x08 /* Private */,
       6,    0,  113,    2, 0x08 /* Private */,
       7,    0,  114,    2, 0x08 /* Private */,
       8,    0,  115,    2, 0x08 /* Private */,
       9,    0,  116,    2, 0x08 /* Private */,
      10,    0,  117,    2, 0x08 /* Private */,
      11,    0,  118,    2, 0x08 /* Private */,
      12,    0,  119,    2, 0x08 /* Private */,
      13,    0,  120,    2, 0x08 /* Private */,
      14,    0,  121,    2, 0x08 /* Private */,
      15,    0,  122,    2, 0x08 /* Private */,
      16,    0,  123,    2, 0x08 /* Private */,
      17,    0,  124,    2, 0x08 /* Private */,
      18,    0,  125,    2, 0x08 /* Private */,
      19,    0,  126,    2, 0x08 /* Private */,
      20,    0,  127,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->floorG(); break;
        case 1: _t->floor1(); break;
        case 2: _t->floor2(); break;
        case 3: _t->floor3(); break;
        case 4: _t->floor4(); break;
        case 5: _t->floor5(); break;
        case 6: _t->floor6(); break;
        case 7: _t->floor7(); break;
        case 8: _t->fireButton(); break;
        case 9: _t->helpButton(); break;
        case 10: _t->upCall(); break;
        case 11: _t->downCall(); break;
        case 12: _t->openDoor(); break;
        case 13: _t->closeDoor(); break;
        case 14: _t->floorSelector(); break;
        case 15: _t->handleTimerRunOut(); break;
        case 16: _t->chooseElevator1(); break;
        case 17: _t->chooseElevator2(); break;
        case 18: _t->chooseElevator3(); break;
        default: ;
        }
    }
    (void)_a;
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_MainWindow.data,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 19)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 19;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 19)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 19;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE

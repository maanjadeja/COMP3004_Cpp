FILES:
centralized_class_diagram.png
designExplanation.pdf
mutliple_sequence.png
RTMFINAL.pdf
single_sequence.png
state_diagram.png
state_diagram_controller.png
useCases.pdf

CODE FILES:
Button.h
Button.cpp
Door.h
Door.cpp
DoorSensor.h
DoorSensor.cpp
Elevator.h
Elevator.cpp
ElevatorButtons.h
ElevatorButtons.cpp
ExternalButtons.h
ExternalButtons.cpp
FloorController.h
FloorController.cpp
Passenger.h
Passenger.cpp
mainwindow.h
mainwindow.cpp
main.cpp

UI FILE:
mainwindow.ui

